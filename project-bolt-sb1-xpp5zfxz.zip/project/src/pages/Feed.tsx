import React from 'react';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Plus } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const SAMPLE_STORIES = [
  {
    id: 1,
    user: {
      id: 'sarah-chen',
      name: 'Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      hasUnseenStory: true,
    },
  },
  {
    id: 2,
    user: {
      id: 'marcus-johnson',
      name: 'Marcus Johnson',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      hasUnseenStory: true,
    },
  },
  {
    id: 3,
    user: {
      id: 'emily-patel',
      name: 'Emily Patel',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      hasUnseenStory: false,
    },
  },
  {
    id: 4,
    user: {
      id: 'james-wilson',
      name: 'James Wilson',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      hasUnseenStory: true,
    },
  },
];

// Extended sample posts to show more variety
const SAMPLE_POSTS = [
  {
    id: 1,
    user: {
      id: 'sarah-chen',
      name: 'Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      grade: '12th Grade',
    },
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600',
    caption: 'Proud to share our science fair project won first place! 🏆 #ScienceFair #TeamWork',
    likes: 124,
    comments: 18,
    timestamp: '2 hours ago',
  },
  {
    id: 2,
    user: {
      id: 'marcus-johnson',
      name: 'Marcus Johnson',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      grade: '11th Grade',
    },
    image: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?w=600',
    caption: 'Basketball team practice going strong! 🏀 Ready for the championship next week. #SchoolSpirit',
    likes: 89,
    comments: 12,
    timestamp: '4 hours ago',
  },
  {
    id: 3,
    user: {
      id: 'emily-patel',
      name: 'Emily Patel',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      grade: '10th Grade',
    },
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600',
    caption: 'Art club exhibition coming up next week! 🎨 #StudentArt #CreativeMinds',
    likes: 156,
    comments: 23,
    timestamp: '6 hours ago',
  },
  {
    id: 4,
    user: {
      id: 'james-wilson',
      name: 'James Wilson',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      grade: '11th Grade',
    },
    image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600',
    caption: 'Debate team heading to nationals! 🎤 Wish us luck! #DebateTeam #Nationals2024',
    likes: 201,
    comments: 45,
    timestamp: '1 day ago',
  },
];

function Feed() {
  const navigate = useNavigate();

  const handleStoryClick = (userId: string) => {
    navigate(`/story/${userId}`);
  };

  return (
    <div className="max-w-xl mx-auto bg-gray-50">
      {/* Stories Section */}
      <div className="bg-white border-b">
        <div className="p-4 overflow-x-auto">
          <div className="flex space-x-4">
            {/* Add Story */}
            <div className="flex-shrink-0">
              <div className="w-16 h-16 relative">
                <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center">
                  <Plus className="w-6 h-6 text-gray-500" />
                </div>
                <button className="absolute bottom-0 right-0 bg-indigo-600 rounded-full p-1">
                  <Plus className="w-4 h-4 text-white" />
                </button>
              </div>
              <p className="text-xs text-center mt-1">Add story</p>
            </div>
            
            {/* Stories List */}
            {SAMPLE_STORIES.map((story) => (
              <div key={story.id} className="flex-shrink-0">
                <button 
                  onClick={() => handleStoryClick(story.user.id)}
                  className="block group"
                >
                  <div className="w-16 h-16 rounded-full relative">
                    <div className={`absolute inset-0 rounded-full ${
                      story.user.hasUnseenStory ? 'bg-gradient-to-tr from-yellow-400 to-fuchsia-600' : 'bg-gray-200'
                    } p-0.5`}>
                      <img
                        src={story.user.avatar}
                        alt={story.user.name}
                        className="w-full h-full object-cover rounded-full border-2 border-white"
                      />
                    </div>
                  </div>
                  <p className="text-xs text-center mt-1 truncate w-16">{story.user.name}</p>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="space-y-6">
        {SAMPLE_POSTS.map((post) => (
          <Post key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
}

function Post({ post }) {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <Link 
          to={`/profile/${post.user.id}`} 
          className="flex items-center space-x-3 group"
        >
          <img
            src={post.user.avatar}
            alt={post.user.name}
            className="w-10 h-10 rounded-full object-cover group-hover:ring-2 ring-indigo-600"
          />
          <div>
            <h3 className="font-semibold text-gray-900 group-hover:text-indigo-600">{post.user.name}</h3>
            <p className="text-sm text-gray-500">{post.user.grade}</p>
          </div>
        </Link>
        <button className="text-gray-500">
          <MoreHorizontal className="w-6 h-6" />
        </button>
      </div>

      {/* Post Image */}
      <img
        src={post.image}
        alt="Post content"
        className="w-full aspect-square object-cover"
      />

      {/* Post Actions */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <button className="text-gray-500 hover:text-red-500">
              <Heart className="w-6 h-6" />
            </button>
            <button className="text-gray-500 hover:text-blue-500">
              <MessageCircle className="w-6 h-6" />
            </button>
            <button className="text-gray-500 hover:text-green-500">
              <Share2 className="w-6 h-6" />
            </button>
          </div>
          <button className="text-gray-500 hover:text-yellow-500">
            <Bookmark className="w-6 h-6" />
          </button>
        </div>

        {/* Likes */}
        <p className="font-semibold text-sm mb-2">{post.likes} likes</p>

        {/* Caption */}
        <p className="text-sm mb-2">
          <Link to={`/profile/${post.user.id}`} className="font-semibold hover:text-indigo-600">
            {post.user.name}
          </Link>{' '}
          {post.caption}
        </p>

        {/* Comments */}
        <button className="text-gray-500 text-sm mb-2">
          View all {post.comments} comments
        </button>

        {/* Timestamp */}
        <p className="text-xs text-gray-500 uppercase">{post.timestamp}</p>
      </div>
    </div>
  );
}

export default Feed;