import React, { useState } from 'react';
import { Image, X } from 'lucide-react';

function CreatePost() {
  const [caption, setCaption] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImageSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
  };

  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Create New Post</h2>

      {/* Image Upload */}
      <div className="mb-4">
        {selectedImage ? (
          <div className="relative">
            <img
              src={selectedImage}
              alt="Selected"
              className="w-full aspect-square object-cover rounded-lg"
            />
            <button
              onClick={removeImage}
              className="absolute top-2 right-2 bg-gray-900 bg-opacity-50 text-white p-1 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <label className="block w-full aspect-square border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-indigo-500 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <div className="h-full flex flex-col items-center justify-center text-gray-500">
              <Image className="w-12 h-12 mb-2" />
              <p className="text-sm font-medium">Click to upload an image</p>
            </div>
          </label>
        )}
      </div>

      {/* Caption */}
      <div className="mb-4">
        <label htmlFor="caption" className="block text-sm font-medium text-gray-700 mb-2">
          Caption
        </label>
        <textarea
          id="caption"
          rows={4}
          className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          placeholder="Write a caption for your post..."
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
        ></textarea>
      </div>

      {/* Tags */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Suggested Tags
        </label>
        <div className="flex flex-wrap gap-2">
          {['#SchoolLife', '#StudyTime', '#ClassOf2024', '#StudentAchievement'].map((tag) => (
            <button
              key={tag}
              className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200"
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Submit Button */}
      <button
        className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
        disabled={!selectedImage || !caption.trim()}
      >
        Share Post
      </button>
    </div>
  );
}

export default CreatePost;