import React from 'react';
import { Settings, Grid, Bookmark, Award } from 'lucide-react';

const PROFILE_DATA = {
  name: 'Alex Thompson',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
  grade: '11th Grade',
  major: 'Science Track',
  bio: '🔬 Future Scientist | 🏃‍♂️ Track Team Captain | 📚 Science Club President',
  stats: {
    posts: 42,
    followers: 286,
    following: 192,
  },
  achievements: [
    'Science Fair Winner 2024',
    'Track & Field MVP',
    'Honor Roll Student',
  ],
};

function Profile() {
  return (
    <div className="max-w-xl mx-auto bg-gray-50">
      {/* Profile Header */}
      <div className="bg-white p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">{PROFILE_DATA.name}</h2>
          <button className="text-gray-600">
            <Settings className="w-6 h-6" />
          </button>
        </div>

        <div className="flex items-start justify-between">
          <img
            src={PROFILE_DATA.avatar}
            alt="Profile"
            className="w-20 h-20 rounded-full object-cover"
          />
          <div className="flex space-x-4 flex-1 justify-around text-center">
            <div>
              <div className="font-bold">{PROFILE_DATA.stats.posts}</div>
              <div className="text-gray-500 text-sm">Posts</div>
            </div>
            <div>
              <div className="font-bold">{PROFILE_DATA.stats.followers}</div>
              <div className="text-gray-500 text-sm">Followers</div>
            </div>
            <div>
              <div className="font-bold">{PROFILE_DATA.stats.following}</div>
              <div className="text-gray-500 text-sm">Following</div>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <div className="text-sm text-gray-700">{PROFILE_DATA.grade} • {PROFILE_DATA.major}</div>
          <p className="text-sm mt-2">{PROFILE_DATA.bio}</p>
        </div>

        <button className="w-full mt-4 bg-gray-100 text-gray-800 py-1.5 rounded font-semibold">
          Edit Profile
        </button>
      </div>

      {/* Achievements Section */}
      <div className="bg-white mt-4 p-4">
        <h3 className="font-semibold mb-3 flex items-center">
          <Award className="w-5 h-5 mr-2 text-indigo-600" />
          Achievements
        </h3>
        <div className="space-y-2">
          {PROFILE_DATA.achievements.map((achievement, index) => (
            <div key={index} className="flex items-center text-sm">
              <div className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></div>
              {achievement}
            </div>
          ))}
        </div>
      </div>

      {/* Content Navigation */}
      <div className="flex border-t mt-4">
        <button className="flex-1 py-3 text-indigo-600 border-t-2 border-indigo-600">
          <Grid className="w-6 h-6 mx-auto" />
        </button>
        <button className="flex-1 py-3 text-gray-400">
          <Bookmark className="w-6 h-6 mx-auto" />
        </button>
      </div>

      {/* Posts Grid */}
      <div className="grid grid-cols-3 gap-1">
        {[...Array(9)].map((_, i) => (
          <div key={i} className="aspect-square bg-gray-200"></div>
        ))}
      </div>
    </div>
  );
}

export default Profile;