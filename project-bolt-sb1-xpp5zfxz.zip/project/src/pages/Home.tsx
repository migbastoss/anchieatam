import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Calendar, Award, BookOpen } from 'lucide-react';

function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-7xl mx-auto p-6">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Left Column - Features */}
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-900">Connect with Your School Community</h2>
            <p className="text-lg text-gray-600">Share your academic journey, showcase achievements, and stay connected with classmates in a safe, school-focused environment.</p>
            
            <div className="grid grid-cols-2 gap-4">
              <FeatureCard 
                icon={<Users className="w-6 h-6 text-indigo-600" />}
                title="Class Connections"
                description="Connect with classmates and form study groups"
              />
              <FeatureCard 
                icon={<Calendar className="w-6 h-6 text-indigo-600" />}
                title="Event Sharing"
                description="Share and discover school events and activities"
              />
              <FeatureCard 
                icon={<Award className="w-6 h-6 text-indigo-600" />}
                title="Achievement Showcase"
                description="Highlight your academic and extracurricular achievements"
              />
              <FeatureCard 
                icon={<BookOpen className="w-6 h-6 text-indigo-600" />}
                title="Academic Timeline"
                description="Document your educational journey"
              />
            </div>

            <button
              onClick={() => navigate('/feed')}
              className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
            >
              Get Started
            </button>
          </div>

          {/* Right Column - Profile Preview */}
          <div className="bg-white rounded-lg shadow-xl p-6">
            <h3 className="text-xl font-semibold mb-4">Create Your Academic Profile</h3>
            <div className="space-y-4">
              <ProfileField label="Basic Info" fields={['Full Name', 'Profile Picture', 'Bio']} />
              <ProfileField label="Academic Details" fields={['Grade/Year Level', 'Class/Section', 'Major/Track']} />
              <ProfileField label="Extracurricular" fields={['Clubs & Organizations', 'Sports Teams', 'Leadership Roles']} />
              <ProfileField label="Achievements" fields={['Academic Awards', 'Competitions', 'Certifications']} />
              <ProfileField label="Interests" fields={['Favorite Subjects', 'Career Goals', 'Study Preferences']} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow-md">
      <div className="mb-2">{icon}</div>
      <h3 className="font-semibold text-gray-900">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  );
}

function ProfileField({ label, fields }) {
  return (
    <div className="border-b border-gray-200 pb-4">
      <h4 className="text-sm font-medium text-gray-500 mb-2">{label}</h4>
      <ul className="space-y-1">
        {fields.map((field, index) => (
          <li key={index} className="text-gray-700 flex items-center">
            <div className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></div>
            {field}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Home;