import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { X, ChevronLeft, ChevronRight, Heart, MessageCircle } from 'lucide-react';

const SAMPLE_STORIES = {
  'sarah-chen': {
    user: {
      name: 'Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    },
    stories: [
      {
        id: 1,
        type: 'image',
        url: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600',
        caption: 'Prepping for the Science Fair! 🔬',
      },
      {
        id: 2,
        type: 'image',
        url: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=600',
        caption: 'Our project coming together! 🧪',
      },
    ],
  },
  'marcus-johnson': {
    user: {
      name: 'Marcus Johnson',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    },
    stories: [
      {
        id: 1,
        type: 'image',
        url: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?w=600',
        caption: 'Game day! 🏀',
      },
    ],
  },
};

function ViewStory() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  const userStories = SAMPLE_STORIES[userId];
  const currentStory = userStories?.stories[currentStoryIndex];

  useEffect(() => {
    if (!currentStory) return;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentStoryIndex < userStories.stories.length - 1) {
            setCurrentStoryIndex(currentStoryIndex + 1);
            return 0;
          } else {
            navigate('/feed');
            return prev;
          }
        }
        return prev + 1;
      });
    }, 30);

    return () => clearInterval(timer);
  }, [currentStory, currentStoryIndex, navigate, userStories?.stories.length]);

  if (!userStories || !currentStory) {
    return null;
  }

  const handlePrevStory = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(currentStoryIndex - 1);
      setProgress(0);
    }
  };

  const handleNextStory = () => {
    if (currentStoryIndex < userStories.stories.length - 1) {
      setCurrentStoryIndex(currentStoryIndex + 1);
      setProgress(0);
    } else {
      navigate('/feed');
    }
  };

  return (
    <div className="fixed inset-0 bg-black">
      {/* Progress Bars */}
      <div className="absolute top-0 left-0 right-0 z-10 p-2 flex gap-1">
        {userStories.stories.map((story, index) => (
          <div key={story.id} className="h-0.5 bg-gray-600 flex-1">
            <div
              className="h-full bg-white transition-all duration-300 ease-linear"
              style={{
                width: `${index === currentStoryIndex ? progress : index < currentStoryIndex ? 100 : 0}%`,
              }}
            />
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img
              src={userStories.user.avatar}
              alt={userStories.user.name}
              className="w-8 h-8 rounded-full object-cover"
            />
            <span className="text-white font-semibold">{userStories.user.name}</span>
          </div>
          <button onClick={() => navigate('/feed')} className="text-white">
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Story Content */}
      <div className="h-full flex items-center justify-center">
        <img
          src={currentStory.url}
          alt="Story"
          className="max-h-full max-w-full object-contain"
        />
      </div>

      {/* Caption */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/50">
        <p className="text-white">{currentStory.caption}</p>
      </div>

      {/* Navigation Buttons */}
      <button
        onClick={handlePrevStory}
        className="absolute left-4 top-1/2 -translate-y-1/2 text-white p-2"
        disabled={currentStoryIndex === 0}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={handleNextStory}
        className="absolute right-4 top-1/2 -translate-y-1/2 text-white p-2"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Quick Actions */}
      <div className="absolute bottom-20 right-4 space-y-4">
        <button className="text-white p-2">
          <Heart className="w-6 h-6" />
        </button>
        <button className="text-white p-2">
          <MessageCircle className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}

export default ViewStory;