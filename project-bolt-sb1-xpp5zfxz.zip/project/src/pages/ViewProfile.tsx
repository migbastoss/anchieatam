import React from 'react';
import { useParams } from 'react-router-dom';
import { Grid, Bookmark, Award, Share2 } from 'lucide-react';

const SAMPLE_PROFILES = {
  'sarah-chen': {
    name: 'Sarah Chen',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    grade: '12th Grade',
    major: 'Biology Track',
    bio: '🧬 Future Biologist | 🏆 Science Fair Winner | 📚 Biology Club President',
    stats: {
      posts: 67,
      followers: 423,
      following: 391,
    },
    achievements: [
      'Science Fair Gold Medal 2024',
      'Biology Olympiad Finalist',
      'Perfect Score - AP Biology',
    ],
  },
  'marcus-johnson': {
    name: 'Marcus Johnson',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    grade: '11th Grade',
    major: 'Sports Science Track',
    bio: '🏀 Varsity Basketball | 🏃‍♂️ Track Team | 💪 Future Sports Therapist',
    stats: {
      posts: 89,
      followers: 567,
      following: 445,
    },
    achievements: [
      'Basketball Team Captain',
      'Regional MVP 2024',
      'Student Athlete Award',
    ],
  },
};

function ViewProfile() {
  const { userId } = useParams();
  const profile = SAMPLE_PROFILES[userId] || SAMPLE_PROFILES['sarah-chen'];

  return (
    <div className="max-w-xl mx-auto bg-gray-50">
      {/* Profile Header */}
      <div className="bg-white p-4">
        <div className="flex items-start justify-between">
          <img
            src={profile.avatar}
            alt={profile.name}
            className="w-20 h-20 rounded-full object-cover"
          />
          <div className="flex space-x-4 flex-1 justify-around text-center">
            <div>
              <div className="font-bold">{profile.stats.posts}</div>
              <div className="text-gray-500 text-sm">Posts</div>
            </div>
            <div>
              <div className="font-bold">{profile.stats.followers}</div>
              <div className="text-gray-500 text-sm">Views</div>
            </div>
            <div>
              <div className="font-bold">{profile.stats.following}</div>
              <div className="text-gray-500 text-sm">Likes</div>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <h2 className="text-xl font-bold">{profile.name}</h2>
          <div className="text-sm text-gray-700">{profile.grade} • {profile.major}</div>
          <p className="text-sm mt-2">{profile.bio}</p>
        </div>

        <button className="w-full mt-4 bg-indigo-600 text-white py-1.5 rounded font-semibold flex items-center justify-center space-x-2">
          <Share2 className="w-4 h-4" />
          <span>Share Profile</span>
        </button>
      </div>

      {/* Achievements Section */}
      <div className="bg-white mt-4 p-4">
        <h3 className="font-semibold mb-3 flex items-center">
          <Award className="w-5 h-5 mr-2 text-indigo-600" />
          Achievements
        </h3>
        <div className="space-y-2">
          {profile.achievements.map((achievement, index) => (
            <div key={index} className="flex items-center text-sm">
              <div className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></div>
              {achievement}
            </div>
          ))}
        </div>
      </div>

      {/* Content Navigation */}
      <div className="flex border-t mt-4">
        <button className="flex-1 py-3 text-indigo-600 border-t-2 border-indigo-600">
          <Grid className="w-6 h-6 mx-auto" />
        </button>
        <button className="flex-1 py-3 text-gray-400">
          <Bookmark className="w-6 h-6 mx-auto" />
        </button>
      </div>

      {/* Posts Grid */}
      <div className="grid grid-cols-3 gap-1">
        {[...Array(9)].map((_, i) => (
          <div key={i} className="aspect-square bg-gray-200"></div>
        ))}
      </div>
    </div>
  );
}

export default ViewProfile;