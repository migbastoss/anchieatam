import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { GraduationCap, Home, Image, User, Bell } from 'lucide-react';

function Layout() {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-indigo-600 text-white p-4 fixed top-0 w-full z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <GraduationCap className="w-8 h-8" />
            <h1 className="text-2xl font-bold">CampusGram</h1>
          </Link>
          {!isHome && (
            <div className="flex items-center space-x-4">
              <Bell className="w-6 h-6 cursor-pointer" />
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className={`${isHome ? '' : 'pt-16 pb-20'} min-h-screen`}>
        <Outlet />
      </main>

      {/* Bottom Navigation */}
      {!isHome && (
        <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex justify-around py-3">
              <Link to="/feed" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
                <Home className="w-6 h-6" />
                <span className="text-xs mt-1">Feed</span>
              </Link>
              <Link to="/create" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
                <Image className="w-6 h-6" />
                <span className="text-xs mt-1">Create</span>
              </Link>
              <Link to="/profile" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
                <User className="w-6 h-6" />
                <span className="text-xs mt-1">Profile</span>
              </Link>
            </div>
          </div>
        </nav>
      )}
    </div>
  );
}

export default Layout;