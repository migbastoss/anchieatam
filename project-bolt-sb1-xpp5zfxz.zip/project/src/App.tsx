import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Feed from './pages/Feed';
import Profile from './pages/Profile';
import CreatePost from './pages/CreatePost';
import ViewProfile from './pages/ViewProfile';
import ViewStory from './pages/ViewStory';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="feed" element={<Feed />} />
          <Route path="profile" element={<Profile />} />
          <Route path="profile/:userId" element={<ViewProfile />} />
          <Route path="create" element={<CreatePost />} />
          <Route path="story/:userId" element={<ViewStory />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;